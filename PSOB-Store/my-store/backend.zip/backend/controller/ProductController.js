const product = require(`../model/ProductModel.js`);


exports.createProduct=async(req,res)=>{
    try {
        const {productName,
        sku,
        category_id,
        price,
        description,
        created_at,
        updated_at}=req.body

        const Product = await product.create({
            productName,
            sku,
            category_id,
            price,
            description,
            created_at,
            updated_at
})
res.status(201).json({message:"success", data:Product})

    } catch (error) {
        res.status(500).json({message:error.message})
    }

    }