const express = require('express');
const routes = express.Router();
const controller = require('../controller/productVarController.js')

routes.get("/",controller.getAllVarient)
routes.get("/:id",controller.getSingleVarient)
routes.delete("/:id",controller.deleteVarient)
routes.put("/:id",controller.editVarient)
routes.post("/",controller.createVarient)

module.exports=routes