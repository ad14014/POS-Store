const varient = require('../model/ProductVarientModel.js');
const product = require('../model/ProductModel.js');

exports.getAllVarient = async (req, res) => {
    try {
        const allVarient = await varient.find()
            .populate('product_id', 'productName created_at updated_at')

        const formattedVarient = allVarient.map(varient => (
            {
                productName: varient.product_id.productName,
                _id: varient._id,
                varientName: varient.variant_name,
                variantValue: varient.variant_value,
                created_at: varient.product_id.created_at,
                updated_at: varient.product_id.updated_at,
                sku: varient.sku,
                price: varient.price

            }
        ))



        res.status(200).json({
            message: "success",
            data: formattedVarient
        })
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

exports.getSingleVarient = async (req, res) => {
    try {
        const varientId = req.params.id

        const Varients = await varient.findById(varientId)
            .populate('product_id', 'productName created_at updated_at')

        const formattedVarient = {

            productName: Varients.product_id.productName,
            _id: Varients._id,
            varientName: Varients.variant_name,
            variantValue: Varients.variant_value,
            created_at: Varients.product_id.created_at,
            updated_at: Varients.product_id.updated_at,
            sku: Varients.sku,
            price: Varients.price

        }


        if (!varient) { res.status(404).json({ message: "Id is not valid" }) }
        res.status(200).json({ message: "success", data: formattedVarient })

    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}
exports.deleteVarient = async (req, res) => {
    try {
        const varientId = req.params.id
        const deleteVarient = await varient.findByIdAndDelete(varientId)
        if (!deleteVarient) { res.status(404).json({ message: `product with this ID:${varientId} is not found ` }) }
        res.status(201).json({ message: `product with this ID:${varientId} is deleted ` })
    } catch (error) {
        res.status(500).json({ message: error.message })
    }

}
exports.editVarient = async (req,res)=>{
    try {
        const ID = req.params.id
        const UpdatedData= req.body
        const editVarient = await varient.findByIdAndUpdate(ID,UpdatedData,{new:true})
        if(!editVarient){res.status(404).json({message:"product is not edited"})}
        res.status(201).json({message:"successfully edited",data:editVarient})
    } catch (error) {

        res.status(500).json({ message: error.message })

    }
}




exports.createVarient = async (req, res) => {
    try {
        const { productName,
            sku,
            price,
            variant_name,
            variant_value,
            refundable, } = req.body;

        const Products = await product.findOne({ productName: productName })
        if (!Products) {
            res.status(404).json({ message: "Product is not define" })
        }
        const ProductVarient = await varient.create({
            variant_name,
            variant_value,
            product_id: Products._id,
            sku,
            price,
            refundable
        })
        res.status(201).json({
            message: "success",
            data: ProductVarient
        })

    } catch (error) {
        res.status(500).json({ message: error.message })
    }

}