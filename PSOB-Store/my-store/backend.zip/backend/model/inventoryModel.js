const mongoose=require('mongoose');
const inventorySchema= new mongoose.Schema({
        _id: mongoose.Schema.Types.ObjectId,
inventoryName:{type:String,required:true},
     Parent_id:mongoose.Schema.Types.ObjectId,
     product_variant_id:mongoose.Schema.Types.ObjectId,
     quantity:{type:Number,required:true},
     location:{type:String,required:true},
     last_updated:{type:Date}
},{collection:"Inventory"})

module.exports=mongoose.model('Inventories',inventorySchema)