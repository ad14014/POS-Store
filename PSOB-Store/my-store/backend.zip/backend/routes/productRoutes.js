const express = require('express');
const routes = express.Router();
const controller = require('../controller/ProductController.js')

routes.post("/",controller.createProduct)

module.exports=routes