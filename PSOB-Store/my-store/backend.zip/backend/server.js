require('dotenv').config()
const express = require('express');
const cors = require('cors');
const app= express();
const port = process.env.PORT||3000;
const dataBase = require('./utils/db.js')
const varientRoutes = require('./routes/VarientRoutes.js')
const productRoutes = require('./routes/productRoutes.js')


app.use(cors())
app.use(express.json())

// routes
app.use("/productVarient",varientRoutes)
app.use("/product",productRoutes)




// database call
dataBase()
app.listen(port,()=>{
    console.log(`running on ${port}`)
})