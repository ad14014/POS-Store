const mongoose = require('mongoose');

const varientSchema= new mongoose.Schema({
        // _id: mongoose.Schema.Types.ObjectId,
product_id:{ type:mongoose.Schema.Types.ObjectId, ref:'product'},
variant_name:{ type:String, required:true},
variant_value:{type:String, required:true},
sku:{type:String, required:true},
price:{type:Number, required:true},
refundable:{type:Boolean}
},{collection:"Product_variant"})

module.exports= mongoose.model("varient",varientSchema)