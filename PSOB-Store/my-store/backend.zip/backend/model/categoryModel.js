const mongoose=require('mongoose');

const categorySchema= new mongoose.Schema({
        
        _id: mongoose.Schema.Types.ObjectId,
categoryName:{type:String,required:true},
        description:{type:Number,required:true}
//  Parent_id:mongoose.Schema.Types.ObjectId
},{collection:"Category"})

module.exports=mongoose.model('category',categorySchema)