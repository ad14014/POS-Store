require('dotenv').config()

const mongoose = require("mongoose");
const MONGO_URI= process.env.MONGO_URI


const db = async ()=>{
try {
    await mongoose.connect(`${MONGO_URI}`)
    console.log(`${MONGO_URI} is connentected`)
    
} catch (error) {
    console.log(error.message)
    }
}
module.exports=db