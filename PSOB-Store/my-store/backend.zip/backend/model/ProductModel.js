const mongoose=require('mongoose');
const productSchema= new mongoose.Schema({
        // _id: mongoose.Schema.Types.ObjectId,
    productName:{type:String,required:true},
    sku:{type:String,required:true},
    category_id:mongoose.Schema.Types.ObjectId,
    price:{type:Number,required:true},
    description:{type:String,required:true},
    created_at:{type:Date,required:true},
    updated_at:{type:Date}

},{collection:"Product"})
module.exports=mongoose.model('product',productSchema)